#ifndef DIVISOR_HPP
#define DIVISOR_HPP

#include <cassert>

#include "prime.hpp"
#include "primeTest.hpp"

template <class Prime, class Int, int _primeFactorCount>
class _Divisor {
public:
	_Divisor(Int n = 1) {
		primeFactorCount = 0;
		multiply(n);
	}

	void multiply(Int n) {
		Int i = 1;
		for (; n >= Prime::_bound && i < 150; ++i) {
			if (n % Prime::prime(i) == 0) {
				n = addPrime(n, Prime::prime(i));
			}
		}
		while (n >= Prime::_bound) {
			if (deterministicMillerRabin<Int>(n)) {
				addPrimeExponent(n, 1);
				return;
			}
			while (n % Prime::prime(i)) {
				++i;
			}
			n = addPrime(n, Prime::prime(i));
		}
		while (n != 1) {
			n = addPrime(n, Prime::minPrimeFactor(n));
		}
	}

	template <class D>
	void multiply(const D& d) {
		for (int i = 0; i < d.primeFactorCount; ++i) {
			addPrimeExponent(d.primeFactor[i], d.primeExponent[i]);
		}
	}

	bool divide(Int n) {
		for (int i = 0; i < primeFactorCount; ++i) {
			while (n % primeFactor[i] == 0 && primeExponent[i]) {
				n /= primeFactor[i];
				--primeExponent[i];
			}
		}
		return n == 1;
	}

	// generate all divisors in [lBound, uBound]
	std::vector<Int> genDivisors(Int lBound, Int uBound) {
		std::vector<Int> res;

		int currentExponent[_primeFactorCount];
		Int currentDivisor[_primeFactorCount];

		currentExponent[0] = 0;
		currentDivisor[0] = 1;

		int pivot = 0;
		while (pivot >= 0) {
			if (currentDivisor[pivot] >= lBound) {
				res.push_back(currentDivisor[pivot]);
			}
			while (pivot < primeFactorCount - 1) {
				++pivot;
				currentExponent[pivot] = 0;
				currentDivisor[pivot] = currentDivisor[pivot - 1];
			}
			while (pivot >= 0 && (currentExponent[pivot] == primeExponent[pivot] || currentDivisor[pivot] > uBound / primeFactor[pivot])) {
				--pivot;
			}
			if (pivot >= 0) {
				++currentExponent[pivot];
				currentDivisor[pivot] *= primeFactor[pivot];
			}
		}

		return res;
	}

public:
	Int addPrime(Int n, Int prime) {
		int exponent = 0;
		while (n % prime == 0) {
			++exponent;
			n /= prime;
		}
		addPrimeExponent(prime, exponent);
		return n;
	}

	void addPrimeExponent(Int prime, int exponent) {
		int i = 0;
		while (i < primeFactorCount && primeFactor[i] != prime) {
			++i;
		}
		if (i == primeFactorCount) {
			primeFactor[i] = prime;
			primeExponent[i] = 0;
			++primeFactorCount;
			assert(primeFactorCount <= _primeFactorCount);
		}
		primeExponent[i] += exponent;
	}

	int primeFactorCount;
	Int primeFactor[_primeFactorCount];
	int primeExponent[_primeFactorCount];
};

template <class Prime, class Int, int _primeFactorCount>
std::ostream& operator << (std::ostream& os, const _Divisor<Prime, Int, _primeFactorCount>& d) {
	if (d.primeFactorCount == 0) {
		os << 1;
	}
	for (int i = 0; i < d.primeFactorCount; ++i) {
		if (i) {
			os << " * ";
		}
		os << d.primeFactor[i] << "^" << d.primeExponent[i];
	}
	return os;
}

#endif // DIVISOR_HPP
