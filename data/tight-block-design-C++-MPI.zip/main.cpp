#include <boost/multiprecision/cpp_int.hpp>
typedef uint64_t u10;								// numbers less than 10^3
typedef uint64_t u36;								// numbers less than 6^10
typedef uint64_t u64;
typedef boost::multiprecision::uint128_t u128;
typedef boost::multiprecision::uint512_t u512;

#include "prime.hpp"
typedef _Prime<int> Prime;
template<>
int Prime::_bound = 10000000;						// should be at least 2^20
Prime::Init _PrimeInit;

#include "divisor.hpp"
typedef _Divisor<Prime, u36, 40> Divisor;

#define BOOST_TIMER_ENABLE_DEPRECATED
#include <boost/timer.hpp>

#include <iostream>
#include <sstream>
#include <fstream>

int testAlpha(u10 s, u36 x, u36 y) {
	u128 P = s;
	P *= x;
	P *= x + 1;
	P /= y;
	// P = alpha_1
	P *= s - 1;
	P *= x + 1;
	P *= x + 2;
	if (P % (2 * (y + 1))) {
		return 1;
	}
	P /= 2 * (y + 1);
	// P = alpha_2
	u512 Q = P;
	for (int i = 3; i <= 6; ++i) {
		Q *= s - i + 1;
		Q *= x + i - 1;
		Q *= x + i;
		u64 t = i * (y + i - 1);
		if (Q % t) {
			return i - 1;
		}
		Q /= t;
		// Q = alpha_i
	}
	return 6;
}

std::string search(u10 s0, u10 s1, u36 X) {
	boost::timer timer;

	u64 sols[7] = {0, 0, 0, 0, 0, 0, 0};

	Divisor d[s1 + 1];
	for (u10 s = 1; s <= s1; ++s) {
		d[s] = Divisor(s);
	}

	std::stringstream res;

	u36 xMin = (X - 1) * 1000000;
	u36 xMax = X * 1000000;
	Divisor x0, x1(xMin + 1);
	for (u36 x = xMin + 1; x <= xMax; ++x) {
		x0 = x1;				// == Divisor(x)
		x1 = Divisor(x + 1);	// == Divisor(x + 1)

		Divisor P(x0);
		P.multiply(x1);

		for (u36 s = s0; s <= s1; ++s) {
			Divisor Q(P);
			Q.multiply(d[s]);
			auto ys = Q.genDivisors(x + s + 2, 2 * x + 1);
			for (auto y: ys) {
				int i = testAlpha(s, x, y);
				for (int k = 1; k <= i; ++k) {
					++sols[k];
				}
				if (i == 6) {
					res << "Solution Found! (" << s << ", " << x << ", " << y << ")\n";
				}
			}
		}

	}

	res << "s in [" << s0 << ", " << s1 << "], "
		<< "X = " << X << ", "
		<< "int p1/p2/p3/p4/p5/p6: " << sols[1] << "/" << sols[2] << "/" << sols[3] << "/" << sols[4] << "/" << sols[5] << "/" << sols[6] << ". "
		<< "Elapsed time: " << timer.elapsed() << " secs.\n";

	return res.str();
}

void run(std::ostream& os, u10 s0, u10 s1, int X) {
	std::string res = search(s0, s1, X);
	os << res;
	os.flush();
}

#include <mpi.h>

int main(int argc, char* argv[]) {
	u10 s0, s1;
	int X;
	if (argc <= 2) {
		std::cout << "Usage: tbd s0 s1 X\n";
		std::cout << "Find positive integer solutions (s, x, y, alpha_i) to the equation:\n";
		std::cout << "\t\t {s \\choose 1} (x)_1 (x + 1)_1 = alpha_1 (y)_1\n";
		std::cout << "\t\t {s \\choose 2} (x)_2 (x + 2)_2 = alpha_2 (y)_2\n";
		std::cout << "\t\t {s \\choose 3} (x)_3 (x + 3)_3 = alpha_3 (y)_3\n";
		std::cout << "\t\t {s \\choose 4} (x)_4 (x + 4)_4 = alpha_4 (y)_4\n";
		std::cout << "\t\t {s \\choose 5} (x)_5 (x + 5)_5 = alpha_5 (y)_5\n";
		std::cout << "\t\t {s \\choose 6} (x)_6 (x + 6)_6 = alpha_6 (y)_6\n";
		std::cout << "\t\t x + s + 2 <= y <= 2 x + 1\n";
		std::cout << "with s in [s0, s1] and x in (0, X] millions.\n";
		std::cout.flush();
		return 1;
	} else {
		s0 = atoi(argv[1]);
		s1 = atoi(argv[2]);
		X = atoi(argv[3]);
	}

    MPI_Init(&argc, &argv);

    int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	MPI_Status status;
	MPI_Request request[size - 1];
	int stop_flag = 0;
	int finish_flag = 0;
	int num = 0;
	if (0 == rank) {
		for (num = size - 1; num < X; ) {
			MPI_Recv(&finish_flag, 1, MPI_INT, MPI_ANY_SOURCE, 99, MPI_COMM_WORLD, &status);
			if (1 == finish_flag) {
				int dest = status.MPI_SOURCE;
				num += 1;
				MPI_Send(&num, 1, MPI_INT, dest, 98, MPI_COMM_WORLD);
			}
		}
		stop_flag = 1;
		for (int i = 1; i < size; i++) {
			MPI_Isend(&stop_flag, 1, MPI_INT, i, 100, MPI_COMM_WORLD, &request[i - 1]);
		}
	} else {
		std::stringstream filename;
		filename << "tmp/" << rank << ".txt";
		std::ofstream os(filename.str());
		if (!os.is_open()) {
			std::cerr << "tmp/" << rank << ".txt failed to open the file." << std::endl;
			MPI_Finalize();
			return 1;
		}
		run(os, s0, s1, rank);
		finish_flag = 1;
		MPI_Irecv(&stop_flag, 1, MPI_INT, 0, 100, MPI_COMM_WORLD, &request[rank - 1]);
		while (!stop_flag) {
			MPI_Send(&finish_flag, 1, MPI_INT, 0, 99, MPI_COMM_WORLD);
			MPI_Recv(&num, 1, MPI_INT, 0, 98, MPI_COMM_WORLD, &status);
			finish_flag = 0;
			run(os, s0, s1, num);
			finish_flag = 1;
			MPI_Test(&request[rank - 1], &stop_flag, &status);
		}
	}
	MPI_Finalize();
	return 0;
}
