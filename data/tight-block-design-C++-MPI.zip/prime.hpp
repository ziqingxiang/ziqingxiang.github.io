#ifndef PRIME_HPP
#define PRIME_HPP

#include <cmath>
#include <cstring>

// All primes strictly smaller than the given bound.
template <class Int>
class _Prime {
public:
	static Int _bound;

private:
	static Int* _prime;
	static Int* _minPrimeFactor;

public:
	static class Init {
	public:
		Init() {
			// The inequality is proved in arXiv:1002.0442 [math.NT].
			Int _primeCount = (Int) (_bound < 60184 ? 6076 : (double) _bound / (log((double) _bound) - 1.1));

			_prime = new Int[_primeCount];
			_minPrimeFactor = new Int[_bound];

			memset(_prime, 0, sizeof(Int) * _primeCount);
			memset(_minPrimeFactor, 0, sizeof(Int) * _bound);

			// We treat 1 as the 0-th ``prime''.
			_prime[0] = 1;
			_minPrimeFactor[0] = 1;

			for (Int i = 2, j = 0; i < _bound; ++i) {
				if (!_minPrimeFactor[i]) {
					++j;
					_prime[j] = i;
					_minPrimeFactor[i] = i;
				}
				for (Int k = 1; k <= j && i * _prime[k] < _bound; ++k) {
					_minPrimeFactor[i * _prime[k]] = _prime[k];
					if (i % _prime[k] == 0) {
						break;
					}
				}
			}
		}
	} init;

	inline static Int prime(const Int i) {
		return _prime[i];
	}

	inline static Int minPrimeFactor(const Int n) {
		return _minPrimeFactor[n];
	}
};

template <class Int>
Int* _Prime<Int>::_prime = 0;

template <class Int>
Int* _Prime<Int>::_minPrimeFactor = 0;
#endif // PRIME_HPP
