#ifndef PRIME_TEST_HPP
#define PRIME_TEST_HPP

#include <boost/multiprecision/integer.hpp>

typedef uint64_t uint40_t;

template <class Int>
bool millerRabin(const Int& n, const Int& d, const int s, const Int& a) {
	if (n == a) {
		return true;
	}
	Int z = boost::multiprecision::powm(a, d, n);
	if (z == 1) {
		return true;
	}
	for (int i = 0; i < s; ++i) {
		if (z == n - 1) {
			return true;
		}
		z = boost::multiprecision::powm(z, 2, n);
	}
	return false;
}

template <class Int>
bool deterministicMillerRabin(const Int&) {
	return false;
}

// https://en.wikipedia.org/wiki/Miller%E2%80%93Rabin_primality_test#Deterministic_variants
// if n < 2^32, it is enough to test a = 2, 7, 61.
template <>
bool deterministicMillerRabin<uint32_t>(const uint32_t& n) {
	if (!(n & 1)) {
		return n == 2;
	}
	uint64_t d = n - 1;
	int s = boost::multiprecision::lsb(d);
	d >>= s;
	return millerRabin<uint32_t>(n, d, s, 2)
		&& millerRabin<uint32_t>(n, d, s, 7)
		&& millerRabin<uint32_t>(n, d, s, 61);
}

// https://en.wikipedia.org/wiki/Miller%E2%80%93Rabin_primality_test#Deterministic_variants
// if n < 2^40, it is enough to test a = 2, 13, 23 and 1662803.
template <>
bool deterministicMillerRabin<uint40_t>(const uint40_t& n) {
	if (!(n & 1)) {
		return n == 2;
	}
	uint40_t d = n - 1;
	int s = boost::multiprecision::lsb(d);
	d >>= s;
	return millerRabin<uint40_t>(n, d, s, 2)
		&& millerRabin<uint40_t>(n, d, s, 13)
		&& millerRabin<uint40_t>(n, d, s, 23)
		&& millerRabin<uint40_t>(n, d, s, 1662803);
}

#endif // PRIME_TEST_HPP
